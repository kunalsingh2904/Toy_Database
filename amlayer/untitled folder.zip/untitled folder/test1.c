#include <stdio.h>
#include "am.h"
#include "testam.h"
#include "pf.h"


#define MAXRECS	50
#define MAX_FNAME_LENGTH 80	/* max length for file name */

main()
{
int id0,id1; /* index descriptor */
char ch;
int sd0,sd1; /* scan descriptors */
int i;
RecIdType recid;	/* record id */
char buf[NAMELENGTH]; /* buffer to store chars */
char fnamebuf[MAX_FNAME_LENGTH];	/* file name buffer */
int recnum;	/* record number */
int numrec;		/* # of records retrieved*/

	/* init */
	//printf("initializing\n");
	PF_Init();
    
    FILE *fp;
//    fp = fopen("testdata1.txt", "r");
    fp = fopen("inputcharfile.txt", "r");
    fflush(fp);
    char line[512];
    
	/* create index on the both field of the record*/
	//printf("creating indices\n");
	xAM_CreateIndex(RELNAME,RECNAME_INDEXNO,CHAR_TYPE,NAMELENGTH);
	xAM_CreateIndex(RELNAME,RECVAL_INDEXNO,INT_TYPE,sizeof(int));

	/* open the index */
	//printf("opening indices\n");
	sprintf(fnamebuf,"%s.%d",RELNAME,RECNAME_INDEXNO);
	id0 = xPF_OpenFile(fnamebuf);
	sprintf(fnamebuf,"%s.%d",RELNAME,RECVAL_INDEXNO);
	id1 = xPF_OpenFile(fnamebuf);

	/* insert into index on character */
	//printf("inserting into index on char\n");
	while ( fgets ( line, NAMELENGTH, fp ) != NULL ) {
		xAM_InsertEntry(id0,CHAR_TYPE,NAMELENGTH,line,IntToRecId(recnum));
    }

	//printf("opening index scan on char\n");
	sd0 = xAM_OpenIndexScan(id0,CHAR_TYPE,NAMELENGTH,EQ_OP,NULL);
	//printf("retrieving recid's from scan descriptor %d\n",sd0);
	numrec = 0;
    char nextKey[512];

	while((recnum=RecIdToInt(xAM_FindNextKey(sd0, nextKey)))>= 0){
		printf("%s\n",nextKey);
        //printf("Hello %s\n",nextKey2);
		numrec++;
	}
	//printf("retrieved %d records\n",numrec);

	/* insert into index on integer */
	//printf("inserting into index of integer\n");
//    int ig;
//	for (recnum=0, ig=0; ig < 150; recnum++, ig++){
//		xAM_InsertEntry(id1,INT_TYPE,sizeof(int),&recnum,IntToRecId(recnum));
//	}
   
    
//    int num;
//    while (fscanf(fp, "%d", &num) != EOF) {
//         xAM_InsertEntry(id1,INT_TYPE,sizeof(int),&num,IntToRecId(recnum));
//    }
//    
//	/* Let's see if the insert works */
//	printf("opening index scan on integer\n");
//	sd1 = xAM_OpenIndexScan(id1,INT_TYPE,sizeof(int),EQ_OP,NULL);
//	printf("retrieving recid's from scan descriptor %d\n",sd1);
//	numrec = 0;
//    char nextKey2[512];
//	while((recnum=RecIdToInt(xAM_FindNextKey(sd1, nextKey2)))>= 0){
//        int keyint;
//        bcopy(nextKey2,(char *)&keyint,AM_si);
//        printf("%d\n", keyint);
//        numrec++;
//	}
//	printf("retrieved %d records\n",numrec);


	/* destroy everything */
	//printf("closing down\n");
	xAM_CloseIndexScan(sd0);
	xAM_CloseIndexScan(sd1);
	xPF_CloseFile(id0);
	xPF_CloseFile(id1);
	xAM_DestroyIndex(RELNAME,RECNAME_INDEXNO);
	xAM_DestroyIndex(RELNAME,RECVAL_INDEXNO);

    printf("Number of seeks required in mergesort for reads: %d\n", nReadSeeks);
    printf("Number of transfers required in mergesort for reads: %d\n", nReadTransfers);
    printf("Number of seeks required in mergesort for writes: %d\n", nWriteSeeks);
    printf("Number of transfers required in mergesort for writes: %d\n", nWriteTransfers);
    
	//printf("test1 done!\n");
}
